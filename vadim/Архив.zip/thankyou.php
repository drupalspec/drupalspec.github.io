<?php

    echo "<h3>Thank you page!</h3>";

?>